
from brain_games.scripts import engine
from brain_games.scripts.games import progression


def main():
    engine.getCheck(progression)


if __name__ == '__main__':
    main()
