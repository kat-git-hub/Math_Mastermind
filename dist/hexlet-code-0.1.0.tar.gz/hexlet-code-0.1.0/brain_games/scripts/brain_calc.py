
from brain_games.scripts import engine
from brain_games.scripts.games.calc import getRightAnswer
rightAnswer, ask_a_question = getRightAnswer()


def main():
    engine.getCheck()


if __name__ == '__main__':
    main()
