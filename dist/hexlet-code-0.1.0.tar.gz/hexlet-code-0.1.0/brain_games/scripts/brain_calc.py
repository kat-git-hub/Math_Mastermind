
from brain_games.scripts import engine
from brain_games.scripts.games import calc


def main():
    engine.getCheck(calc)


if __name__ == '__main__':
    main()
