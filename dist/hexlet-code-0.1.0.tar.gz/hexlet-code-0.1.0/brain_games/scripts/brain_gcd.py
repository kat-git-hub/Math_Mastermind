
from brain_games.scripts import engine
from brain_games.scripts.games import gcd


def main():
    engine.getCheck(gcd)


if __name__ == '__main__':
    main()
