
from brain_games import launch_the_game
from brain_games.scripts.games import gcd


def main():
    launch_the_game.play_on(gcd)


if __name__ == '__main__':
    main()
