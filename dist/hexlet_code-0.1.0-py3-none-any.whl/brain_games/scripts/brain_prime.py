
from brain_games import launch_the_game
from brain_games.scripts.games import prime


def main():
    launch_the_game.play_on(prime)


if __name__ == '__main__':
    main()
