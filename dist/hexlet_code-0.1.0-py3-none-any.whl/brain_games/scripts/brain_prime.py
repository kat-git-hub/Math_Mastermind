
from brain_games.scripts import engine
from brain_games.scripts.games import prime


def main():
    engine.getCheck(prime)


if __name__ == '__main__':
    main()
