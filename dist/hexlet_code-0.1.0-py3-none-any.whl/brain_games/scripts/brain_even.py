from brain_games.scripts import engine
from brain_games.scripts.games import even


def main():
    engine.getCheck(even)


if __name__ == '__main__':
    main()
