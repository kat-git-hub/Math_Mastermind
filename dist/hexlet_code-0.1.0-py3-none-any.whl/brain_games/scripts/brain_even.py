from brain_games import launch_the_game
from brain_games.scripts.games import even


def main():
    launch_the_game.play_on(even)


if __name__ == '__main__':
    main()
